
import sqlite3 from 'sqlite3';
const db=new sqlite3.Database('./appointments.db');
db.run(`CREATE TABLE IF NOT EXISTS appointments(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT,phone TEXT,appointment_time TEXT,
reminder_sent INTEGER DEFAULT 0)`);
export default db;
