
import express from 'express';
import db from '../database.js';
import {sendSMS} from '../smsService.js';
const router=express.Router();
router.get('/',(req,res)=>db.all('SELECT * FROM appointments ORDER BY id DESC',[],(_,r)=>res.json(r)));
router.post('/',(req,res)=>{
 const {name,phone,appointment_time}=req.body;
 db.run('INSERT INTO appointments(name,phone,appointment_time) VALUES(?,?,?)',
 [name,phone,appointment_time], async function(err){
  if(err) return res.status(500).json(err);
  await sendSMS(phone,`Appointment confirmed for ${name}`);
  res.json({success:true,id:this.lastID});
 });
});
export default router;
