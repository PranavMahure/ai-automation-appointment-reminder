
import cron from 'node-cron';
import db from './database.js';
import {sendSMS} from './smsService.js';
cron.schedule('* * * * *',()=>{
 db.all('SELECT * FROM appointments WHERE reminder_sent=0',[],async(_,rows)=>{
  const now=new Date();
  for(const r of rows){
   const diff=new Date(r.appointment_time)-now;
   if(diff>0 && diff<=3600000){
    await sendSMS(r.phone,`Reminder for ${r.name}`);
    db.run('UPDATE appointments SET reminder_sent=1 WHERE id=?',[r.id]);
   }
  }
 });
});
