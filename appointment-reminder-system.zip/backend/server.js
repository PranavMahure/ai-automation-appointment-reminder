
import express from 'express';
import cors from 'cors';
import './scheduler.js';
import routes from './routes/appointments.js';
const app=express();
app.use(cors());
app.use(express.json());
app.use('/appointments',routes);
app.listen(5000,()=>console.log('Backend running on 5000'));
