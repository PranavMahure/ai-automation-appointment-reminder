
export async function sendSMS(phone,message){
 console.log('MOCK SMS =>',phone,message);
}
