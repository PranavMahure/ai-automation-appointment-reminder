
import {useState,useEffect} from 'react';
import axios from 'axios';
export default function App(){
 const [form,setForm]=useState({name:'',phone:'',appointment_time:''});
 const [data,setData]=useState([]);
 const load=()=>axios.get('http://localhost:5000/appointments').then(r=>setData(r.data));
 useEffect(()=>{load()},[]);
 const submit=async(e)=>{
  e.preventDefault();
  await axios.post('http://localhost:5000/appointments',form);
  load();
 };
 return <div style={{padding:20}}>
 <h1>WhatsApp/SMS Appointment Reminder System</h1>
 <form onSubmit={submit}>
 <input placeholder='Name' onChange={e=>setForm({...form,name:e.target.value})}/><br/><br/>
 <input placeholder='Phone' onChange={e=>setForm({...form,phone:e.target.value})}/><br/><br/>
 <input type='datetime-local' onChange={e=>setForm({...form,appointment_time:e.target.value})}/><br/><br/>
 <button>Book Appointment</button>
 </form>
 <h2>Appointments</h2>
 <table border='1'><thead><tr><th>Name</th><th>Phone</th><th>Time</th></tr></thead>
 <tbody>{data.map(a=><tr key={a.id}><td>{a.name}</td><td>{a.phone}</td><td>{a.appointment_time}</td></tr>)}</tbody></table>
 </div>
}
